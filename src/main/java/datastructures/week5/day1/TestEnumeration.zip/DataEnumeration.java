package datastructures.week5.day1;

public class DataEnumeration {
    /**
     * Identify test data for  email address

     * test data for email address
     * [aplhanumeric][specialChars].+[aplhanumeric]@domain[.co.in][.com]
     *
     * 1. abc+34xyv@domain.co.in
     * 2. 123#abc+wry@domain.com
     * 3. abcd@domain.com
     * 4. my$domain@domain.com
     * 5. first.last@domain.com
     * 6. first.last@domain123.com
     */


    /**
     * Identify test data for the method → “private int findMaxMulValue(int [] A)”
     *
     * 1. [1,1,1]
     * 2. [0,12,2]
     * 3. [10, 100,1000]
     * 4. [-1,0,1]
     * 5. [-8,1, 9, -1]
     * 6. [3,5,15] -> here 3*5 gives 15 and there is 15 also present, what to return.
     *
     *
     */
}
