package datastructures.week5.day1;

public class TestEnumerationTemplate {
    /**
     * - UI
     *     - cross browser
     *     - diff platforms (web/ app/ tablet/ IOT)
     *     -
     * - API
     *     - search
     *     - deffered login / pre-login
     *     - w/ JWT/ bearer, w/o tokens
     * - Compatibility -
     * - Usability- user expereince
     * - Security -
     * - Performance
     *     - load sequentially
     *     - spike test
     *     - concurrent
     * - Functional
     *     - business flows--> purely functional thingy
     *     - field level validations --> data enumeration
     * - Accessibility
     *     - magnifiers- dyselxic
     *     - text to speech
     *     - scanner through search
     */

}
