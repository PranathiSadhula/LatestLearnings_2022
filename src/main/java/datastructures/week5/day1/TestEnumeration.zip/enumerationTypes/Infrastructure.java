package datastructures.week5.day1.enumerationTypes;

public class Infrastructure {
    /**
     * server capabilities
     * how much ram
     * how much memeory
     * how much runtime(heap) memory
     * cloud components
     * Deployments
     * caching quota sizing
     *     --. ex : how much memory you can have on caching like 5gb or 10gb data will cached on festve sales.
     *
     * Ddos attack --> when data is injected unnecasrrily
     *        ex : IRCTC for tatkal booking, it takes alot time, so if Ddos attack is not handled well, someone can use high internet to hit multiple times.
     *
     */
}
