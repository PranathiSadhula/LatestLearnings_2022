package datastructures.week5.day1.enumerationTypes;

public class Accesibility {
    /**
     * in how many diff ways, appln can be accessed.
     *      - every diff user able to access the appln.
     *      - external divices like alexa able to access to appln.
     *
     *
     */
}
