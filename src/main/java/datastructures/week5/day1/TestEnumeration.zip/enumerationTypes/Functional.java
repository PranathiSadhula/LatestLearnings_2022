package datastructures.week5.day1.enumerationTypes;

public class Functional {
    /**
     * Field level validations
     *  - apply data ENUMERATON
     * flow validations( business use cases)
     * Pages/screens validation
     *
     */
}
