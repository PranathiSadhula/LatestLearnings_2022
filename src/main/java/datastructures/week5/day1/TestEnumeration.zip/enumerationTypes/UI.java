package datastructures.week5.day1.enumerationTypes;

public class UI {
    /**
     * Cross browser
     * Cross platforms
     * Alignment/ design
     * Diff  form factors/ aspect ratios
     * Multilingual aspects.\
     * accessibility.\
     * resposiveness -> what is latency to get response
     */
}
