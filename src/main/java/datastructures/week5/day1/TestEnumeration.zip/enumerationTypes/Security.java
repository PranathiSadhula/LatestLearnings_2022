package datastructures.week5.day1.enumerationTypes;

public class Security {
    /**
     * - threats to appln can be happend in diff ways.
     * ex : http method : pOST
     *
     * - data injections
     * - XSS - cross site scripting
     * - Header validations(CSP, X-frame-options)
     * -
     */
}
