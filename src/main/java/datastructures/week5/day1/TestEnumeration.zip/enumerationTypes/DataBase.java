package datastructures.week5.day1.enumerationTypes;

public class DataBase {
    /**
     * Schema migrations ->
     * Constraints(Keys)
     * Indices
     * Idempotency
     */
}
